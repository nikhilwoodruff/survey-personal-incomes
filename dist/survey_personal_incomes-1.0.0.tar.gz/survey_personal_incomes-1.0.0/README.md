# survey_personal_incomes

This is a lightweight Python package to store, manage and load Survey of Personal Incomes microdata.