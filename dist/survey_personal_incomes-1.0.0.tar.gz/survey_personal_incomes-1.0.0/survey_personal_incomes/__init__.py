from survey_personal_incomes.load import SPI
